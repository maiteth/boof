(function () {
    'use strict';

    const app = angular.module('main', ['ngSanitize', 'boof-layout', 'boof-table']); // les [] pour initialiser un module, sinon on le recupere



})();